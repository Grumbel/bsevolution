//     BSEvolution - A simple toy to simulate the evolution of a
//                   biegosaurus and the stachelophyte
//     Copyright (C) 2000  Ingo Ruhnke <grumbel@gmx.de>
//
//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*; 
import java.awt.event.*; 

class ConfigDialog 
    extends Frame
    implements ActionListener 
{
    private Label     biego_max_label;
    private TextField biego_max_field;
    
    private Label     biego_start_width_label;
    private TextField biego_start_width_field;

    private Label     biego_start_height_label;
    private TextField biego_start_height_field;

    private Label     stego_max_label;
    private TextField stego_max_field;

    private Label     stego_start_width_label;
    private TextField stego_start_width_field;

    private Label     stego_start_height_label;
    private TextField stego_start_height_field;
    
    private Button ok_button;
    private Button cancel_button;
    
    public ConfigDialog () 
    {
	setLayout(new BorderLayout ());
	setSize (250, 220);

	setTitle ("BSEvolution - Startwerte");

	Panel panel = new Panel ();
		
	add ("North", panel);

	biego_max_field = new TextField ("100");
	biego_max_label = new Label ("Biego Max: ");

	biego_start_width_label = new Label ("Biego Start Hight: ");
	biego_start_width_field = new TextField ("100");

	biego_start_height_label = new Label ("Biego Start Hight: "); 
	biego_start_height_field = new TextField ("100");

	stego_max_field = new TextField ("100");
	stego_max_label = new Label ("Stego Max: ");

	stego_start_width_label = new Label ("Stego Start Hight: ");
	stego_start_width_field = new TextField ("100");

	stego_start_height_label = new Label ("Stego Start Hight: "); 
	stego_start_height_field = new TextField ("100");

	ok_button = new Button ("Ok");
	cancel_button = new Button ("Cancel");

	panel.setLayout (new GridLayout(6,2));
	
	panel.add (biego_max_label);
	panel.add (biego_max_field);

	panel.add (biego_start_width_label);
	panel.add (biego_start_width_field);

	panel.add (biego_start_height_label);
	panel.add (biego_start_height_field);

	panel.add (stego_max_label);
	panel.add (stego_max_field);

	panel.add (stego_start_width_label);
	panel.add (stego_start_width_field);

	panel.add (stego_start_height_label);
	panel.add (stego_start_height_field);

	add ("South", ok_button);
	ok_button.addActionListener (this);
    }

    public void actionPerformed(ActionEvent e) 
    {
	if (e.getActionCommand ().equals ("Ok")) 
	    {	
		Main.main.config_dialog.setVisible (false);
		Main.main.main_window.setVisible (true);
		Main.main.start_world ();
	    }
    }
}

// EOF //
