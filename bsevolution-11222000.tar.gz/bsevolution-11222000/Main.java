// 	$Id: Main.java,v 1.3 2000/11/02 08:57:44 iruhnke Exp iruhnke $	

/** This class creates all the other classes and manages the main loop. */
class Main 
    extends Thread
{
    private World world;

    // Gui Elements
    public MainWindow main_window;
    public StatGraph stat_graph;
    public ConfigDialog config_dialog;

    private boolean running;
    private int update_time;
    private int refresh_rate;
    public static Main main;

    public Main () {
	update_time = 1000;
	refresh_rate = 10;

	// Construct all parts of the user interface
	world = new World ();
	main_window = new MainWindow ();
	stat_graph = new StatGraph ();
	config_dialog = new ConfigDialog ();

	main_window.setVisible (true);

	// Starting ourself
	this.start ();
    }

    /** We create only the main thread here, all the real work is done
        then thread */
    public static void main (String args[])
    {
	main = new Main ();
    }

    // The main loop
    public void run () {
	running = false;
	int refresh_counter = 0;
	
	// Main loop
	while (true) 
	    {
		if (running) 
		    {
			world.update ();
			//world.print ();
		
			stat_graph.update ();

			//System.out.println ("Refresh_counter: " + refresh_counter);
			//System.out.println ("Refresh_rate: " + refresh_rate);
			refresh_counter++;
			
			main_window.update_value_display();
			stat_graph.update ();

			// We update the GUI only every refresh_rate step
			if (refresh_counter >= refresh_rate)
			    {
				refresh_counter = 0;
				main_window.update_canvas ();
			    }
		    }
		try {
		    sleep (update_time);
		} catch (InterruptedException e) {
		    System.out.println ("updating...");
		}
	    }
    }

    public int get_refresh_rate () {
	return refresh_rate;
    } 

    
    public void set_refresh_rate (int rrate) {
	refresh_rate = rrate;
    } 

    public int get_update_time () {
	return update_time;
    } 

    public void set_update_time (int u_time) {
	update_time = u_time;
    } 

    public World get_world () {
	return world;
    }

    public void start_world () {
	running = true;
    }

    public void stop_world () {
	running = false;
    }

    /** Interrupt the sleep so that the main loop gets the new
        update_time and refresh_rate, without the need to wait for the
        next loop cycle. */
    public void update () 
    {
	try {
	    this.interrupt ();
	}
	catch (IllegalMonitorStateException me) {
	    System.out.println (" -------- IllegalMonitorStateException caugt ---------");
	}
    }
}

// EOF //
