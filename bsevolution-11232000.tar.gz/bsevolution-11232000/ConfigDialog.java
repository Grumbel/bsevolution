//     BSEvolution - A simple toy to simulate the evolution of a
//                   biegosaurus and the stachelophyte
//     Copyright (C) 2000  Ingo Ruhnke <grumbel@gmx.de>
//
//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*; 
import java.awt.event.*; 

class ConfigDialog 
    extends Frame
    implements ActionListener 
{
    private Label     biego_max_label;
    private TextField biego_max_field;
    
    private Label     biego_start_width_label;
    private TextField biego_start_width_field;

    private Label     biego_start_height_label;
    private TextField biego_start_height_field;

    private Label     stachelo_max_label;
    private TextField stachelo_max_field;

    private Label     stachelo_start_width_label;
    private TextField stachelo_start_width_field;

    private Label     stachelo_start_height_label;
    private TextField stachelo_start_height_field;
    
    private Button ok_button;
    private Button cancel_button;
    
    public ConfigDialog () 
    {
	setLayout(new BorderLayout ());
	setSize (250, 260);

	setTitle ("BSEvolution - Startwerte");

	Panel panel = new Panel ();
		
	add ("North", panel);

	biego_max_field = new TextField ("100");
	biego_max_label = new Label ("Biego Max: ");

	biego_start_width_label = new Label ("Biego Start Hight: ");
	biego_start_width_field = new TextField ("100");

	biego_start_height_label = new Label ("Biego Start Hight: "); 
	biego_start_height_field = new TextField ("100");

	stachelo_max_field = new TextField ("100");
	stachelo_max_label = new Label ("Stachelo Max: ");

	stachelo_start_width_label = new Label ("Stachelo Start Hight: ");
	stachelo_start_width_field = new TextField ("100");

	stachelo_start_height_label = new Label ("Stachelo Start Hight: "); 
	stachelo_start_height_field = new TextField ("100");

	ok_button = new Button ("Ok");
	cancel_button = new Button ("Abbrechen");

	panel.setLayout (new GridLayout(6,2));
	
	panel.add (biego_max_label);
	panel.add (biego_max_field);

	panel.add (biego_start_width_label);
	panel.add (biego_start_width_field);

	panel.add (biego_start_height_label);
	panel.add (biego_start_height_field);

	panel.add (stachelo_max_label);
	panel.add (stachelo_max_field);

	panel.add (stachelo_start_width_label);
	panel.add (stachelo_start_width_field);

	panel.add (stachelo_start_height_label);
	panel.add (stachelo_start_height_field);

	Panel button_panel = new Panel ();
	add ("South", button_panel);
	button_panel.add(ok_button);
	button_panel.add(cancel_button);
	ok_button.addActionListener (this);
	cancel_button.addActionListener (this);
    }

    public void set_config ()
    {
	try {
	    int biego_start_width = Integer.parseInt (biego_start_width_field.getText ());
	    if (biego_start_width >= 0)
		Main.main.get_world ().get_biego ().set_width (biego_start_width);
	    else
		new MessageBox ("Biego Breite muss positiv sein");
	} catch (NumberFormatException e) {
	    new MessageBox ("Biego Breite muss eine Zahl sein");
	}

	try {
	    int biego_start_height = Integer.parseInt (biego_start_height_field.getText ());
	    if (biego_start_height >= 0)
		Main.main.get_world ().get_biego ().set_height (biego_start_height);
	    else
		new MessageBox ("Biego H�he muss positiv sein");
	} catch (NumberFormatException e) {
	    new MessageBox ("Biego H�he muss eine Zahl sein");
	}
	
	try {
	    int biego_max = Integer.parseInt (biego_max_field.getText ());
	    if (biego_max >= 0)
		Main.main.get_world ().set_bmax (biego_max);
	    else
		new MessageBox ("Biego Max Wert muss positiv sein");
	} catch (NumberFormatException e) {
	    new MessageBox ("Biego Max Wert muss eine Zahl sein");
	}

	try {
	    int stachelo_start_width = Integer.parseInt (stachelo_start_width_field.getText ());
	    if (stachelo_start_width >= 0)
		Main.main.get_world ().get_stachelo ().set_width (stachelo_start_width);
	    else
		new MessageBox ("Stachelo Breite muss positiv sein");
	} catch (NumberFormatException e) {
	    new MessageBox ("Stachelo Breite muss eine Zahl sein");
	}

	try {
	    int stachelo_start_height = Integer.parseInt (stachelo_start_width_field.getText ());
	    if (stachelo_start_height >= 0)
		Main.main.get_world ().get_stachelo ().set_height (stachelo_start_height);
	    else
		new MessageBox ("Stachelo H�he muss positiv sein");
	} catch (NumberFormatException e) {
	    new MessageBox ("Stachelo H�he muss eine Zahl sein");
	}
	
	try {
	    int stachelo_max = Integer.parseInt (stachelo_max_field.getText ());
	    if (stachelo_max >= 0)
		Main.main.get_world ().set_smax(stachelo_max);
	    else
		new MessageBox ("Stachelo Max Wert muss positiv sein");
	} catch (NumberFormatException e) {
	    new MessageBox ("Stachelo Max Wert muss eine Zahl sein");
	}
    }

    public void actionPerformed(ActionEvent e) 
    {
	if (e.getActionCommand ().equals ("Ok")) 
	    {	
		Main.main.config_dialog.setVisible (false);
		set_config ();
		Main.main.redisplay ();
	    }
	else if (e.getActionCommand ().equals ("Abbrechen"))
	    {
		Main.main.config_dialog.setVisible (false);		
	    }
    }
}

// EOF //
