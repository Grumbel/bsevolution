//     BSEvolution - A simple toy to simulate the evolution of the
//                   biegosaurus and the stachelophyte
//     Copyright (C) 2000  Ingo Ruhnke <grumbel@gmx.de>
//
//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*; 
import java.awt.color.*; 
import java.awt.event.*; 
import java.awt.image.BufferedImage;
import java.awt.image.*;

/** The main window of the application */
class MainWindow
    implements KeyListener, 
	       ItemListener,
	       ActionListener, 
	       WindowListener
{
    private Label status;
    private Scrollbar update_time;
    private Scrollbar refresh_rate;
    private WorldDisplay canvas;
    private ValueDisplay value_display;
    private Frame frame;
    private Label update_time_label;
    private Label refresh_rate_label;
    private Label evo_steps;
    private Label current_winner;

    public void itemStateChanged(ItemEvent e) 
    {
	if (e.getStateChange() == 1)
		Main.main.stat_graph.setVisible (true);
	else
		Main.main.stat_graph.setVisible (false);
    }

    public void actionPerformed(ActionEvent e) {
	if (e.getActionCommand ().equals ("Optionen")) {
	    System.out.println ("Optionen");
	    Main.main.stop_world ();
	    Main.main.config_dialog.setVisible (true);
	} else if (e.getActionCommand ().equals ("Fortsetzen")) {
	    System.out.println ("Fortsetzen");
	    status.setText ("Status: l�uft");
	    Main.main.start_world ();
	} else if (e.getActionCommand ().equals ("Anhalten")) {
	    System.out.println ("Anhalten");
	    status.setText ("Status: gestoppt");
	    Main.main.stop_world ();
	} 
    }

    public void setVisible (boolean show)
    {
	System.out.println ("Gui Pointer: " + frame);
	frame.setVisible (show);
	if (show)
	    canvas.repaint ();
    }

    // Once this is called it will never return
    public MainWindow () {
	frame = new Frame ();
	Panel panel = new Panel ();
	Panel button_panel = new Panel();

	frame.addWindowListener(this);
	frame.setTitle ("BSEvolution");

	panel.setLayout(new FlowLayout());
	panel.add (button_panel);
	button_panel.setLayout(new GridLayout(11, 1));

	frame.setLayout(new BorderLayout ());
	// Gui Elements
	canvas = new WorldDisplay (500, 450);
	frame.add ("West", canvas);

	value_display = new ValueDisplay ();
	frame.add ("South", value_display);
	
	// Buttons
	Button restart_button = new Button ("Optionen");
	status         = new Label ("Status: gestoppt");
	Button start_button   = new Button ("Fortsetzen");
	Button stop_button    = new Button ("Anhalten");

	restart_button.addActionListener (this);
	start_button.addActionListener (this);
	stop_button.addActionListener (this);

	button_panel.add (restart_button);
	button_panel.add (status);
	button_panel.add (start_button);
	button_panel.add (stop_button);

	update_time = new Scrollbar(Scrollbar.HORIZONTAL, 1000, 250, 1, 2000);
	// new TextField (Integer.toString(Main.main.get_update_time ()), 10);
	update_time_label = new Label ("Update Time:");
	//update_time.addKeyListener (this);
	update_time.addAdjustmentListener (new UpdateTimeListener ());
	button_panel.add (update_time_label);
	button_panel.add (update_time);

	refresh_rate = new Scrollbar(Scrollbar.HORIZONTAL, 0, 10, 0, 50);
	//= new TextField (Integer.toString(Main.main.get_refresh_rate ()), 10);
	refresh_rate_label = new Label ("Refresh Rate:");
	refresh_rate.addAdjustmentListener (new RefreshRateListener ());
	button_panel.add (refresh_rate_label);
	button_panel.add (refresh_rate);
    
	Checkbox checkbox = new Checkbox ("Show Graph", false);
	checkbox.addItemListener (this);
	button_panel.add (checkbox);

	button_panel.add (evo_steps = new Label ("Evo.Schritte: 0"));
	button_panel.add (current_winner = new Label (""));

	//update_time = new TextField (Integer.toString(Main.main.get_update_time ()), 10);
	frame.setSize (650, 550);
	frame.add ("East", panel);
    }

    public void update_canvas() 
    {
	//System.out.println ("updateing canvas");
	canvas.repaint();
    }
    
    public void update_value_display() 
    {
	value_display.update ();
	refresh_rate_label.setText ("Neuzeichenen: " + Main.main.get_refresh_rate () + "/Durchlauf");
	update_time_label.setText ("EvoSchleife: " + Main.main.get_update_time () + "millisec");
	evo_steps.setText ("Evo.Schritte: " + Main.main.get_evo_steps ());
	current_winner.setText ("CurrentWinner: " + Main.main.get_world ().get_current_winner ());
    }

    public boolean isDoubleBuffered () {
	System.out.println ("Call double buffer------------------------");
	return true;
    }
    public void keyPressed (KeyEvent e) {
	if (e.getKeyCode () == e.VK_ENTER) {
	    try {
		// grumbel Main.main.set_update_time (Integer.parseInt (update_time.getText ()));
		Main.main.update ();
	    } catch (NumberFormatException a) {
		System.out.println("not a number");
	    }

	    // System.out.println ("Enter pressed");
	}
    }

    public void keyReleased (KeyEvent e) {
    }
    
    public void keyTyped(KeyEvent e) {
    }

    public void windowActivated(WindowEvent e)
    {
	System.out.println ("window ... opened");
    }
    
    public void windowClosed(WindowEvent e)
    {
	System.out.println ("window ... opened");
    }
    
    public void windowClosing(WindowEvent e)
    {
	System.out.println ("window ... opened");
    }
    
    public void windowDeactivated(WindowEvent e)
    {
	System.out.println ("window ... opened");
    }
    
    public void windowDeiconified(WindowEvent e)
    {
	System.out.println ("window ... opened");
    }
    
    public void windowIconified(WindowEvent e)
    {
	System.out.println ("window ... opened");
    }
    
    public void windowOpened(WindowEvent e) 
    {
	System.out.println ("window ... opened");
    }
}


/** This canvas displays the data of the world class in a nice way */
class WorldDisplay 
    extends DoubleBufferedCanvas
    implements ImageObserver
{
    // Biego elements
    Image hals_v;
    Image hals_h;
    Image kopf;
    Image winkel;
    Image biego;

    // Stachelo elements
    Image green;
    Image baum;
    Image stacheln;

    Image background;

    public WorldDisplay (int w, int h) 
    {
	super (w, h);
	hals_v     = Toolkit.getDefaultToolkit().createImage ("images/hals_v.gif");
	hals_h     = Toolkit.getDefaultToolkit().createImage ("images/hals_h.gif");
	kopf       = Toolkit.getDefaultToolkit().createImage ("images/kopf.gif");
	baum       = Toolkit.getDefaultToolkit().createImage ("images/baum.gif");
	green      = Toolkit.getDefaultToolkit().createImage ("images/green.gif");
	stacheln   = Toolkit.getDefaultToolkit().createImage ("images/stacheln.gif");
	winkel     = Toolkit.getDefaultToolkit().createImage ("images/winkel.gif");
	biego      = Toolkit.getDefaultToolkit().createImage ("images/biego.gif");
	background = Toolkit.getDefaultToolkit().createImage ("images/background.gif");
    }

    /** Paint the world */
    public void buffered_paint (Graphics canvas) 
    {
	canvas.drawImage (background, 0,0, this);
	paint_stachelo (canvas, 100, 440, 
			Main.main.get_world ().get_stachelo ().get_width (), 
			Main.main.get_world ().get_stachelo ().get_height ());
	paint_biego (canvas, 410, 440 - 162,
		     Main.main.get_world ().get_biego ().get_width (),
		     Main.main.get_world ().get_biego ().get_height ());
    }

    /** Paint the stachelo image to the given Graphics object */
    public void paint_stachelo (Graphics canvas, 
				int x_pos, int y_pos,
				int width, int height) 
    {
	//width = (int) (Math.random () *  200) + 40;
	//height = (int) (Math.random () * 200) + 50;

	// We need to change the height a bit so that it fits onto the
	// screen
	height += 162;
	width  += 50;

	//System.out.println ("Painting Stachelo");
	//System.out.println ("Loading images");

	int num_tiles = (int)((height / 42.0) + 1.0);
	float tile_height = (float) height / num_tiles + 1;	

	for (int i = 1; i <= num_tiles; i++)
	    canvas.drawImage (baum, x_pos,y_pos - (int) (i * tile_height),
			      28, (int) tile_height + 1,
			      this);
	canvas.drawImage (green, x_pos - 32, y_pos - 30 - height, this);
	// 108 90
	canvas.drawImage (stacheln, x_pos - width + 20, y_pos - 90,
			  width * 2, 101,
			  this);
    }

    /** Paint the biego image to the given Graphics object */
    public void paint_biego (Graphics canvas, 
			     int x_pos, int y_pos,
			     int width, int height) 
    {
	//System.out.println ("Painting Biego");
	// biego groesse wird in screen coordinaten umgewandelt
	//width = (int) (Math.random () *  200);
	//height = (int) (Math.random () * 200);

	//System.out.println ("Canvas painting...");
	World world = Main.main.get_world ();
	world.paint (canvas);

	//	canvas.drawImage (biego, 57 + x_pos, 35 + 37 + y_pos,
	//		  200, 200,
	//		  observer);

	canvas.drawImage (biego, x_pos - 38, y_pos, this);

	int num_tiles = (int)((height / 37.0) + 1.0);
	if (num_tiles == 0) {
	    System.out.println ("--- numtiles: height= " + height);
	    System.exit (0);
	}
	float tile_height = (float) height / num_tiles + 1;
	//System.out.println (" height: " + num_tiles);
	//System.out.println (" tile_height: " + tile_height);

	for (int i = 1; i <= num_tiles ; i++)
	    canvas.drawImage (hals_v, 
			      x_pos, 
			      y_pos - (int)(tile_height * i),
			      28, (int) tile_height + 1,
			      this);

	canvas.drawImage (winkel, x_pos - 4, y_pos - height - 34, this);

	num_tiles = (int)((width / 37.0) + 1.0);

	if (num_tiles == 0) {
	    System.out.println ("--- numtiles: width = " + width);
	    System.exit (0);
	}

	float tile_width = (float)width / num_tiles + 1;

	//System.out.println ("width: " + num_tiles);
	//System.out.println ("tile_width: " + tile_height);

	for (int i = 1; i <= num_tiles ; i++)
	    canvas.drawImage (hals_h,
			      x_pos - (int)(i * tile_width),
			      y_pos - height - 34,
			      (int) tile_width + 1, 28,
			      this);

	canvas.drawImage (kopf, x_pos - width - 60, 
			  y_pos - height - 36, this);
    }

    public boolean imageUpdate(Image img,
			       int infoflags,
			       int x,
			       int y,
			       int width,
			       int height)
    {
	System.out.println("imageUpdate------------------------------------------------");
	return true;
    }    
}    

/** A panel at the bottom of the main window, which displays the
    current height and width of the creatures */
class ValueDisplay 
    extends Panel 
{
    Label biego;
    Label stachelo;
    Label height;
    Label width;
    Label biego_height;
    Label biego_width;
    Label stachelo_height;
    Label stachelo_width;        
    Label label;

    ValueDisplay () 
    {
	label = new Label ("Ma�e\\Art",  Label.CENTER);
	biego    = new Label ("Biego",  Label.CENTER);
	stachelo = new Label ("Stachelo",  Label.CENTER);
	height   = new Label ("H�he",  Label.CENTER);
	width    = new Label ("Breite",  Label.CENTER);
	biego_width  = new Label ("8",  Label.CENTER);
	biego_height = new Label ("88",  Label.CENTER);
	stachelo_width  = new Label ("9",  Label.CENTER);
	stachelo_height = new Label ("99",  Label.CENTER);

	setLayout (new GridLayout (3, 3));
	add (label);
	add (biego);
	add (stachelo);
	add (width);
	add (biego_width);
	add (stachelo_width);
	add (height);
	add (biego_height);
	add (stachelo_height);
    }
    
    /// Updating the bottom panel with the new width and height values
    void update () 
    {
	biego_width.setText (Integer.toString (Main.main.get_world ().get_biego ().get_width ()));
	biego_height.setText (Integer.toString (Main.main.get_world ().get_biego ().get_height ()));
	stachelo_width.setText (Integer.toString (Main.main.get_world ().get_stachelo ().get_width ()));
	stachelo_height.setText (Integer.toString (Main.main.get_world ().get_stachelo ().get_height ()));
    }
}

class RefreshRateListener
    implements AdjustmentListener
{
    public void adjustmentValueChanged(AdjustmentEvent e)
    {
	Main.main.set_refresh_rate (e.getValue ());
	Main.main.update ();
	System.out.println ("-- Refresh Adjust changed  --" + e.getValue ());
    }
}

class UpdateTimeListener
    implements AdjustmentListener
{
    public void adjustmentValueChanged(AdjustmentEvent e)
    {
	Main.main.set_update_time (e.getValue ());
	Main.main.update ();
	System.out.println ("-- Update Adjust changed  --" + e.getValue ());
    }
}

// EOF //
